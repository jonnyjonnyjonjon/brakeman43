module Brakeman
  Version = "4.3.0"
end
