module ProxyThing
  class X; end

  module Proxied
    def self.included(controller)
    end
  end
end
