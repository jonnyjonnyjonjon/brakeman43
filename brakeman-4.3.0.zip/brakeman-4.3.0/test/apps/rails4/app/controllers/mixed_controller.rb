class MixedController < ApplicationController
    include ProxyThing::Proxied
end
