# Be sure to restart your server when you modify this file.

Rails4::Application.config.session_store :encrypted_cookie_store, key: '_rails4_session'
