class BaseController < ActionController::Base
  # missing protect_from_forgery call
end
