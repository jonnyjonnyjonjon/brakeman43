class Noticia
end
