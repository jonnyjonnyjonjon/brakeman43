class ChildController < BaseThing
  def action_in_child
    #Should get @from_parent here
  end
end
