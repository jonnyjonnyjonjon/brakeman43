ActionDispatch::ParamsParser::DEFAULT_PARSERS.delete(Mime::XML)
