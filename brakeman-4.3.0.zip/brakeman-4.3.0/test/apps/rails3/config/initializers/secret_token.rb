# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails3::Application.config.secret_token = '5cd420fa1791cbbe44796ff5d37af5eaea9e4a821c18cb4947c5a0002ca5751970e0376909bc6ee8da7430982f1e529ee856512abb1f1d6ea442c021893cb993'
