class Unprotected < Protected
  serialize :unsafe_stuff
end
