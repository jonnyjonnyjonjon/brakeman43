class Protected < ActiveRecord::Base
  attr_accessible nil
end

