class <%= file_name.camelize %> < ActiveRecord::Base
end
