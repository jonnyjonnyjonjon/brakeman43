class Alib < $SOME_CONSTANT
end
