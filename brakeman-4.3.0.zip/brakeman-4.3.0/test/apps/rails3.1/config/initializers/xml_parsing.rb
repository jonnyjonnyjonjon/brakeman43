ActiveSupport::XmlMini.backend = "REXML"
