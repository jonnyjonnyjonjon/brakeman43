# this value will be overwritten in unset_escape_json.rb
ActiveSupport.escape_html_entities_in_json = true
