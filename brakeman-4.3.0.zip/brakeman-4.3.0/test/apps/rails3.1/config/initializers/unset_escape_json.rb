# this overwrites the value set in set_escape_json
ActiveSupport.escape_html_entities_in_json = false