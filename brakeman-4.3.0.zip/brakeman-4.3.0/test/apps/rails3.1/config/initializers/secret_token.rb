# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails31::Application.config.secret_token = 'bc1889b8c46e86b3becee7c3abf7bb935b024b86eac43acb820478dc524417144a006e0edf8191d2d1017a6404922b7824e667c8c8656b60604c821e13283b72'
