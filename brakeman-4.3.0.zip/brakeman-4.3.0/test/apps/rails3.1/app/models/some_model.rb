class SomeModel < @some_variable
end
