# Be sure to restart your server when you modify this file.

Rails.application.config.session_store :cookie_store, key: '_rails4_non_standard_structure_session'
