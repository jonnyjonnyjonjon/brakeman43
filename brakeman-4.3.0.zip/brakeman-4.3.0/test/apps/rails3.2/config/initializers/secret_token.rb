# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails32::Application.config.secret_token = 'e721d0d7e8e912026b379d7219b5947da6a954f6c1b7c09ab7b44b873346ee17a780890e6d034fe6bd5ac52cced7b4ebe1971c3f34d0d1e735302b0bd4a0bd62'
