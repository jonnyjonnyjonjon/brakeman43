class NoProtection < ActiveRecord::Base
  # Leave this class empty for Rescanner tests
end
